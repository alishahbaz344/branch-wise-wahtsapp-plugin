<?php
/**
 * Plugin Name: Branch WhatsApp Sticky Button
 * Plugin URI:  https://atechno.pk
 * Description: Display a branch-specific WhatsApp sticky button on designated pages with a beautiful admin UI.
 * Version:     1.0
 * Author:      Ali Shahbaz
 * Author URI:  https://atechno.pk
 * License:     GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/* ===========================================================================
   SETTINGS: Save branch mappings (page slug => WhatsApp number)
============================================================================ */
define( 'BWSB_OPTION', 'branch_whatsapp_button_settings' );

/**
 * Retrieve the branch mappings.
 *
 * @return array Array of branch maps. Format: [ ['slug' => 'branch-slug', 'number' => 'WhatsApp number'], ... ]
 */
function bwsb_get_settings() {
    $settings = get_option( BWSB_OPTION, [] );
    return is_array( $settings ) ? $settings : [];
}

/* ===========================================================================
   ADMIN: Create settings page with dynamic table UI
============================================================================ */
add_action( 'admin_menu', 'bwsb_add_admin_menu' );
function bwsb_add_admin_menu() {
    add_options_page(
        'Branch WhatsApp Button Settings',
        'Branch WhatsApp Button',
        'manage_options',
        'branch-whatsapp-button',
        'bwsb_settings_page'
    );
}

function bwsb_settings_page() {
    // Save settings if form is submitted.
    if ( isset( $_POST['bwsb_submit'] ) && check_admin_referer( 'bwsb_settings_save', 'bwsb_nonce' ) ) {
        $rows = [];
        if ( isset( $_POST['bwsb_branch'] ) && is_array( $_POST['bwsb_branch'] ) ) {
            foreach ( $_POST['bwsb_branch'] as $index => $branch_slug ) {
                $branch_slug = sanitize_title( $branch_slug );
                $number      = sanitize_text_field( $_POST['bwsb_number'][ $index ] );
                if ( ! empty( $branch_slug ) && ! empty( $number ) ) {
                    $rows[] = [
                        'slug'   => $branch_slug,
                        'number' => $number,
                    ];
                }
            }
        }
        update_option( BWSB_OPTION, $rows );
        echo '<div id="message" class="updated notice is-dismissible"><p>Settings saved.</p></div>';
    }

    // Retrieve existing settings.
    $settings = bwsb_get_settings();
    ?>
    <div class="wrap">
        <h1>Branch WhatsApp Button Settings</h1>
        <form method="post" action="">
            <?php wp_nonce_field( 'bwsb_settings_save', 'bwsb_nonce' ); ?>
            <table class="widefat" id="bwsb-table">
                <thead>
                    <tr>
                        <th>Page Slug (branch)</th>
                        <th>WhatsApp Number <small>(with country code, no plus sign)</small></th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( ! empty( $settings ) ) : ?>
                        <?php foreach ( $settings as $index => $map ) : ?>
                            <tr>
                                <td>
                                    <input type="text" name="bwsb_branch[]" value="<?php echo esc_attr( $map['slug'] ); ?>" required>
                                </td>
                                <td>
                                    <input type="text" name="bwsb_number[]" value="<?php echo esc_attr( $map['number'] ); ?>" required>
                                </td>
                                <td>
                                    <button class="button bwsb-remove-row" type="button">Remove</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3">
                            <button id="bwsb-add-row" class="button" type="button">Add Row</button>
                        </td>
                    </tr>
                </tfoot>
            </table>
            <p class="submit">
                <input type="submit" name="bwsb_submit" id="submit" class="button button-primary" value="Save Settings">
            </p>
        </form>
    </div>
    <style>
        /* Simple styling for the admin table */
        #bwsb-table input[type="text"] {
            width: 100%;
            padding: 6px;
            box-sizing: border-box;
        }
    </style>
    <script>
        (function($){
            $(document).ready(function(){
                // Add a new table row
                $('#bwsb-add-row').on('click', function(){
                    var newRow = '<tr>' +
                        '<td><input type="text" name="bwsb_branch[]" required></td>' +
                        '<td><input type="text" name="bwsb_number[]" required></td>' +
                        '<td><button class="button bwsb-remove-row" type="button">Remove</button></td>' +
                        '</tr>';
                    $('#bwsb-table tbody').append(newRow);
                });
                // Remove row on click
                $(document).on('click', '.bwsb-remove-row', function(){
                    $(this).closest('tr').remove();
                });
            });
        })(jQuery);
    </script>
    <?php
}

/* ===========================================================================
   FRONT-END: Output the WhatsApp sticky button if the current page matches a branch mapping
============================================================================ */
add_action( 'wp_footer', 'bwsb_display_whatsapp_button' );
function bwsb_display_whatsapp_button() {
    if ( ! is_page() ) {
        return;
    }

    global $post;
    if ( ! isset( $post->post_name ) ) {
        return;
    }
    $current_slug = $post->post_name;
    $settings     = bwsb_get_settings();
    $number       = '';

    if ( ! empty( $settings ) ) {
        foreach ( $settings as $map ) {
            if ( $current_slug === $map['slug'] ) {
                $number = $map['number'];
                break;
            }
        }
    }

    if ( empty( $number ) ) {
        return;
    }

    ?>
    <style>
        .bwsb-whatsapp-sticky {
            position: fixed;
            bottom: 20px;
            left: 20px; /* Changed from right to left */
            z-index: 9999;
            /*background-color: #25D366;*/
            border-radius: 50%;
            /*box-shadow: 0 4px 12px rgba(0,0,0,0.3);*/
            transition: all 0.3s ease;
            width: 100px;
            height: 100px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .bwsb-whatsapp-sticky:hover {
            transform: scale(1.1);
            /*box-shadow: 0 6px 16px rgba(0,0,0,0.4);*/
        }

        .bwsb-whatsapp-sticky img {
            width: 100px;
            height: 100px;
        }

        @media screen and (max-width: 600px) {
            .bwsb-whatsapp-sticky {
                bottom: 15px;
                left: 15px;
                width: 50px;
                height: 50px;
            }

            .bwsb-whatsapp-sticky img {
                width: 28px;
                height: 28px;
            }
        }
    </style>

    <div class="bwsb-whatsapp-sticky">
        <a href="https://wa.me/<?php echo esc_attr( $number ); ?>" target="_blank" rel="noopener noreferrer">
            <img src="http://localhost/games/wp-content/uploads/2025/07/sm_5b321c99945a2-removebg-preview.png" alt="WhatsApp Chat">
        </a>
    </div>
    <?php
}

